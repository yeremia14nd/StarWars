package com.example.starwars.util

object Constants {

    const val BASE_URL = "https://swapi.dev/api/"
}