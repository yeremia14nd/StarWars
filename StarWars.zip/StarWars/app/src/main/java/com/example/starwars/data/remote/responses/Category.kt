package com.example.starwars.data.remote.responses

data class Category(
    val films: String,
    val people: String,
    val planets: String,
    val species: String,
    val starships: String,
    val vehicles: String
)