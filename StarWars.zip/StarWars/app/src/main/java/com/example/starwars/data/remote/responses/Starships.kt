package com.example.starwars.data.remote.responses

data class Starships(
    val count: Int,
    val next: String,
    val previous: Any,
    val results: List<ResultXXXXX>
)